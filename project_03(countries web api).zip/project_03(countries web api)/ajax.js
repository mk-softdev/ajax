//console.log('test')

let container = document.querySelector('.container')

let xhr = new XMLHttpRequest();

xhr.open('GET', 'https://restcountries.eu/rest/v2/all', true);

xhr.onload = function() {
    if (this.status === 200) {

        let jsonData = JSON.parse(this.responseText)

        let html = '';


        for (let i = 0; i < jsonData.length; i++) {
            if (jsonData[i].name == 'India' || jsonData[i].name == 'United States of America') {
                html +=
                    `
                <div class="card" style="width:400px">
                    <div class="card-body">
                    <img class="card-img-top" src="${jsonData[i].flag}" style="width:100%">
                        <h4 class="card-title">Country: ${jsonData[i].name}</h4>
                        <h5 class="card-title">Region: ${jsonData[i].region}</h5>
                        <h5 class="card-title">Population: ${jsonData[i].population}</h5>     
                        <p>Language: ${jsonData[i].languages[0].name}</p>
                        <p>Currency: ${jsonData[i].currencies[0].name}</p>
                </div>
            `
                container.innerHTML = html;
            }
        }


        //console.log(jsonData)
    } else {
        console.error('ERROR!')
    }
}


// xhr.addEventListener('load', function() {

//     let [data] = JSON.parse(xhr.responseText)
//     if (xhr.readyState === 4) {
//         console.log(data);
//     }

//     let output = '';
//     for (let i = 0; i < data.length; i++) {

//         output += `

//         <div class="card" style="width:400px">
//             <img class="card-img-top" src="${data[i].flag}" style="width:100%">
//             <div class="card-body">
//                 <h4 class="card-title">Country: ${data[i].name}</h4>
//                 <h5 class="card-title">Region: ${data[i].region}</h5>
//                 <h5 class="card-title">Population: ${data[i].population}</h5>
//                 <p>Language: ${data[i].languages[0].name}</p>
//                 <p>Currency: ${data[i].currencies[0].name}</p>
//             </div>
//         </div>
//     `
//     }


//     container.insertAdjacentHTML('beforeend', output);
// })

xhr.send();